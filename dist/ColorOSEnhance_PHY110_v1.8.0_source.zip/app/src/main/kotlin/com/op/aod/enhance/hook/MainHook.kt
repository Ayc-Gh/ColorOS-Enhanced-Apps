package com.op.aod.enhance.hook

import android.app.Application
import android.app.Instrumentation
import android.content.Context
import android.os.Build
import io.github.oshin.windowcapture.CompatibilityPolicy
import com.op.aod.enhance.data.AodConfigStore
import com.op.aod.enhance.hook.AodDurationController.hookAodDurationControl
import com.op.aod.enhance.hook.AodSettingsHook.hookAodAllDaySupportSettings
import com.op.aod.enhance.hook.BrightnessHook.hookInitBrightnessFix
import com.op.aod.enhance.hook.BrightnessHook.hookRunningBrightnessBoost
import com.op.aod.enhance.hook.LowLightHideHook.hookLowLightAodHide
import com.op.aod.enhance.hook.PanoramicHook.hookPanoramicAllDaySupport
import com.op.aod.enhance.hook.SingleClickBlockHook.hookSingleClickWakeUpBlock
import io.github.libxposed.api.XposedModule

object MainHook {
    @Volatile private var cachedContext: Context? = null
    val hostAppContext: Context? get()=cachedContext?:fetchContext()?.also{bindHostContext(it,"reflection-fallback")}

    fun install(module:XposedModule,classLoader:ClassLoader,hostPackage:String){
        AodLog.bind(module)
        HostDiagnostics.bind(module.getRemotePreferences("aod_runtime_status"), hostPackage)
        val runtime=HookRuntime(module,classLoader)
        installContextCapture(runtime)
        val context=runCatching {
            val thread=Class.forName("android.app.ActivityThread")
            thread.getMethod("getSystemContext").invoke(thread.getMethod("currentActivityThread").invoke(null)) as Context
        }.getOrNull()
        val version=runCatching{context?.packageManager?.getPackageInfo(hostPackage,0)?.longVersionCode}.getOrNull()
        if(!CompatibilityPolicy.rom(Build.MODEL,Build.VERSION.SDK_INT,Build.DISPLAY)||version==null||!CompatibilityPolicy.host(hostPackage,version)){
            HostDiagnostics.compatibility="unsupported"
            HostDiagnostics.compatibilityReason="系统或息屏组件版本尚未适配，已保留原生行为"
            return
        }
        HostDiagnostics.compatibility="ready"
        HostDiagnostics.compatibilityReason="本机版本与接口已校验"
        AodConfigReader.bindPrefs(module.getRemotePreferences(AodConfigStore.PREFS_NAME),hostPackage)
        when(hostPackage){
            SYSTEM_UI->{
                runtime.hookWithLog("Brightness.Init"){hookInitBrightnessFix()}
                runtime.hookWithLog("Brightness.Running"){hookRunningBrightnessBoost()}
                runtime.hookWithLog("Duration.NativeTimeout"){hookAodDurationControl()}
                runtime.hookWithLog("Panoramic.AllDay"){hookPanoramicAllDaySupport()}
                runtime.hookWithLog("SingleClick.Block"){hookSingleClickWakeUpBlock()}
                runtime.hookWithLog("LowLight.Block"){hookLowLightAodHide()}
            }
            OPLUS_AOD->runtime.hookWithLog("AodSettings.AllDay"){hookAodAllDaySupportSettings()}
        }
    }

    private fun installContextCapture(runtime:HookRuntime){
        runCatching {
            val method=Instrumentation::class.java.getDeclaredMethod("callApplicationOnCreate",Application::class.java)
            runtime.intercept("aod.context.application-on-create",method){chain->
                val app=chain.getArg(0) as? Application
                if(app!=null)bindHostContext(app,"Instrumentation.callApplicationOnCreate")
                chain.proceed()
            }
        }.onFailure{AodLog.w("HOST_CONTEXT","context capture hook unavailable",it)}
    }

    private fun bindHostContext(context:Context,source:String){
        val app=context.applicationContext?:context
        val first=cachedContext==null
        cachedContext=app
        HostDiagnostics.attach(app)
        if(first)AodLog.i("HOST_CONTEXT","bound source=$source package=${app.packageName}")
    }

    private fun fetchContext():Context?=runCatching{
        Class.forName("android.app.ActivityThread").getMethod("currentApplication").invoke(null) as? Context
    }.getOrNull()

    private inline fun HookRuntime.hookWithLog(name:String,block:HookRuntime.()->Unit){
        feature = name
        HostDiagnostics.registry.begin(name)
        AodLog.i("HOOK_REGISTER","start name=$name")
        runCatching{block()}.onFailure{failure(it.message ?: it.javaClass.simpleName);AodLog.e("HOOK_REGISTER","failed name=$name",it)}
        HostDiagnostics.registry.seal(name)
        val status = HostDiagnostics.registry.snapshot().first { it.name == name }
        AodLog.i("HOOK_REGISTER", "result=${status.state} name=$name paths=${status.paths.size} failures=${status.failures.size} skipped=${status.skipped.size}")
    }

    private const val SYSTEM_UI="com.android.systemui"
    private const val OPLUS_AOD="com.oplus.aod"
}
